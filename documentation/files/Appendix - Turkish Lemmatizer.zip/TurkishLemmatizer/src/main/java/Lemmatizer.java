import py4j.GatewayServer;
import zemberek.morphology.ambiguity.Z3MarkovModelDisambiguator;
import zemberek.morphology.analysis.SentenceAnalysis;
import zemberek.morphology.analysis.WordAnalysis;
import zemberek.morphology.analysis.tr.TurkishMorphology;
import zemberek.morphology.analysis.tr.TurkishSentenceAnalyzer;
import zemberek.tokenization.TurkishSentenceExtractor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Timo on 14.08.2017.
 */
public class Lemmatizer {
    private TurkishSentenceExtractor extractor = TurkishSentenceExtractor.DEFAULT;
    private TurkishMorphology morphology = TurkishMorphology.createWithDefaults();
    private Z3MarkovModelDisambiguator disambiguator = new Z3MarkovModelDisambiguator();
    private TurkishSentenceAnalyzer analyzer = new TurkishSentenceAnalyzer(morphology, disambiguator);
    // Allowed tags
    List<String> allowedPOSTags = Arrays.asList("Verb", "Noun", "Adj", "Adv", "Postp", "Num");

    public Lemmatizer() throws IOException {
    }

    public List<String> lemmatize(String document) {
        // Normalize spaces
        document = document.replaceAll("\\p{Zs}", " ");

        // extract sentences from document (Sentence Boundary Detection)
        List<String> sentences = extractor.fromParagraph(document);

        // initialize return list
        ArrayList<String> tokens = new ArrayList<String>();

        // analyze each sentence (POS-Tagging, Lemmatization)
        for (String sentence:sentences) {
            // POS-Tagging
            SentenceAnalysis analysis = analyzer.analyze(sentence);

            // Disambiguation (Rule-based POS-Tagging)
            analyzer.disambiguate(analysis);

            // Lemmatization
            for (SentenceAnalysis.Entry entry : analysis) {
                // Return best-match

                for (WordAnalysis token : entry.parses.subList(0, 1)) {
                    if(allowedPOSTags.contains(token.getPos().shortForm)) {
                        tokens.add(token.getLemma() + "/" + token.getPos().shortForm);
                    }
                }
            }
        }
        return tokens;
    }

    public List<String> analyze_word(String word) {
        // Normalize spaces
        word = word.replaceAll("\\p{Zs}", " ");

        // initialize return list
        ArrayList<String> tokens = new ArrayList<String>();

        List<WordAnalysis> results = morphology.analyze(word);
        for (WordAnalysis token : results) {
            if(allowedPOSTags.contains(token.getPos().shortForm)) {
                tokens.add(token.getLemma() + "/" + token.getPos().shortForm);
            }
        }
        return tokens;
    }

    public static void main(String[] args) {
        try {
            Lemmatizer app = new Lemmatizer();
            GatewayServer gws = new GatewayServer(app);
            gws.start();

        } catch(IOException e) {
            e.printStackTrace();
        }
    }
}
