import csv
from collections import defaultdict
from preprocessing import pre_process_keyword
import regex
import unicodedata
from pattern.de import find_lemmata as find_lemmata_de
from pattern.en import find_lemmata as find_lemmata_en
from pattern.de import parse as parse_de
from pattern.en import parse as parse_en
from zemberek import ZemberekGateway
from py4j.protocol import Py4JJavaError
import logging
from six import u
import io

csv.field_size_limit(131072 * 4)

STRIP_NUMERIC = regex.compile(ur'(((?![\d])\p{P}*+\p{L}\p{M}*+\p{P}*+)+)', regex.UNICODE)
STRIP_ALL = regex.compile(ur'(((?![\d])\p{L}\p{M}*+)+)', regex.UNICODE)

REPLACE_DASH = regex.compile(ur'[\p{Pd}\/\\]', regex.UNICODE)  # replace with \s
TOKENIZE = regex.compile(ur'((\p{P}*+(?:\p{L}|\p{M}|\d)+\p{P}*+)+)', regex.UNICODE)  # tokenizer
STRIP_QUOTES = regex.compile(ur'[\p{Ps}\p{Pe}\p{Pi}\p{Pf}\p{Pc}]', regex.UNICODE)  # remove before lemmatization
STRIP_PUNCTUATION = regex.compile(ur'\p{P}', regex.UNICODE)  # remove after lemmatization
ALLOWED_TAGS = regex.compile('(NN|VB|RB|JJ)')

def preprocess(document, language):
    if language in ['de', 'tr', 'en']:
        # normalize
        # replace '-'
        # tokenize
        content = REPLACE_DASH.sub(' ', document['content'])

        content = u(' ').join([unicodedata.normalize('NFKC', match.group())
                               for match in TOKENIZE.finditer(content)])

        # strip quotes
        content = STRIP_QUOTES.sub('', content)

        # lemmatize
        if language == 'de':
            # de
            parsed = parse_de(content, lemmata=True, collapse=False)
        elif language == 'tr':
            # tr
            try:
                parsed = ZemberekGateway.parse(content)
            except Py4JJavaError as e:
                logging.info(unicode(e))
                parsed = []
        else:
            # en
            parsed = parse_en(content, lemmata=True, collapse=False)

        result = []
        if language == 'tr':
            for dirty_lemma in parsed:
                dirty_lemma, tag = dirty_lemma.rsplit("/", 1)
                lemma = STRIP_PUNCTUATION.sub('', dirty_lemma)
                lemma = lemma.lower()
                lemma += "/" + tag
                result.append(lemma.encode('utf8'))
        else:
            for sentence in parsed:
                for token, tag, _, _, dirty_lemma in sentence:
                    # strip 'all other punctuation'
                    lemma = STRIP_PUNCTUATION.sub('', dirty_lemma)

                    if ALLOWED_TAGS.match(tag):
                        lemma = lemma.lower()
                        lemma += "/" + tag[:2]
                        result.append(lemma.encode('utf8'))
        return result

def keyword_search(data, language):
    # pre processing
    text = preprocess(data, language)

    for lemma in text:
        lemma = lemma.split("/")[0].lower()

        if lemma in dictionary[language]:
            data['match'] = "1"
            return data

    data['match'] = "0"
    return data

language = 'tr'

# read dictionary
with io.open('baseline_TUR.txt', encoding="utf-8") as dict_file:
    dictionary = defaultdict(set)
    dict_entries = dict_file.readlines()
    for line_orig, line_processed, tokens in pre_process_keyword(dict_entries, language):
        for word in tokens:
            for variant in word:
                dictionary[language].add(variant)

# gold standard
with open('Turkey.csv') as gs_in_file, \
        open('Turkey_scored_v4.csv', "w") as gs_out_file:
    gs_reader = csv.DictReader(gs_in_file, delimiter=",")
    gs_writer = csv.DictWriter(gs_out_file, delimiter=";", fieldnames=gs_reader.fieldnames + ['match'])
    gs_writer.writeheader()

    for data in gs_reader:
        for key in data.keys():
            data[key] = data[key].decode("utf-8")

        data = keyword_search(data, language)

        for key in data.keys():
            data[key] = data[key].encode("utf-8")

        gs_writer.writerow(data)

