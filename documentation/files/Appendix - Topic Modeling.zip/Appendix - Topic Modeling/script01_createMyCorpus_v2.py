#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (C) 2010 Radim Rehurek <radimrehurek@seznam.cz>
# Copyright (C) 2012 Lars Buitinck <larsmans@gmail.com>
# Copyright (C) 2018 Blanked <Blanked>
# Licensed under the GNU LGPL v2.1 - http://www.gnu.org/licenses/lgpl.html

"""
Convert articles from a text dump to (sparse) vectors. The input is a
directory containing plain text files for each document.

This actually creates three files:

* `NAME_wordids.txt`: mapping between words and their integer ids
* `NAME_bow.mm`: bag-of-words (word counts) representation, in
  Matrix Matrix format
* `NAME_tfidf.mm`: TF-IDF representation
* `NAME.tfidf_model`: TF-IDF model dump

NAME can be set in the config file. (see example.config.json)

The output Matrix Market files can then be compressed (e.g., by bzip2) to save
disk space; gensim's corpus iterators can work with compressed input, too.

`DEFAULT_DICT_SIZE` controls how many of the most frequent words to keep (after
removing tokens that appear in more than 10% of all documents). Defaults to
100,000.

If you have the `pattern` package installed, this script will use a fancy
lemmatization to get a lemma of each token (instead of plain alphabetic
tokenizer). The package is available at https://github.com/clips/pattern .

Example: python -u script01_createMyCorpus_v2.py -c example.config.json
"""

import logging
import os.path

from gensim.corpora import Dictionary, MmCorpus
from gensim.models import TfidfModel
from myCorpus_v2 import MyCorpus
from config import config

# Wiki is first scanned for all distinct word types (~7M). The types that
# appear in more than 10% of articles are removed and from the rest, the
# DEFAULT_DICT_SIZE most frequent types are kept.
DEFAULT_DICT_SIZE = 100000


def make_corpus(cfg):
    program = cfg.name
    logger = logging.getLogger(program)

    logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s')
    logging.root.setLevel(level=logging.INFO)
    logger.info("running %s" % cfg.name)

    if not os.path.isdir(os.path.dirname(cfg.paths.results)):
        os.makedirs(cfg.paths.results)
        print("Created dir: " + os.path.dirname(cfg.paths.results))

    debug = ''

	# initialize corpus with configuration
    my_corpus = MyCorpus(cfg)
	
    # only keep the most frequent words
    my_corpus.dictionary.filter_extremes(no_below=20, no_above=0.1, keep_n=DEFAULT_DICT_SIZE)
	
    # save dictionary and bag-of-words (term-document frequency matrix)
    MmCorpus.serialize(cfg.paths.corpus_mm, my_corpus, progress_cnt=10000) 
    my_corpus.dictionary.save_as_text(cfg.paths.dictionary)

    # load back the id->word mapping directly from file
    # this seems to save more memory, compared to keeping the my_corpus.dictionary object from above
    dictionary = Dictionary.load_from_text(cfg.paths.dictionary)
    del my_corpus

    # initialize corpus reader and word->id mapping
    mm = MmCorpus(cfg.paths.corpus_mm)

    # build tfidf model
    tfidf = TfidfModel(mm, id2word=dictionary, normalize=True)
    tfidf.save(cfg.paths.tfidf_model)

    # save tfidf vectors in matrix market format
    MmCorpus.serialize(cfg.paths.tfidf_mm, tfidf[mm], progress_cnt=10000)

    logger.info("finished running %s" % program)


if __name__ == '__main__':
    make_corpus(config)

