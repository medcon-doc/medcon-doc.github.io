# -*- coding: 'utf-8' -*-

"""
Rank the corpus according to the selected relevant topics

This creates LDA topic models for each of the specified topic model sizes:
* `NAME_relevant_articles`: a file containing the relevance scores for each document in the corpus

NAME be set in config.json

Example: python -u script04_selectRelevantArticles_v2.py -c example.config.json
"""

import logging
import gensim
from config import config
import io


def infer_topics(lda_model, relevant_topics, processed_files, corpus_mm, relevant_articles_file):
    logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)

    print("Searching texts that contain the following topics: ", relevant_topics)
    # load model
    my_lda_model = gensim.models.ldamodel.LdaModel.load("%s_%s" % (lda_model, num_topic), mmap='r')

    #  get the names of the files in corpus (by the order in which they were added, read from log created in script01)
    filename_index = get_file_names(processed_files)  # dict: index -> fileName

    # load corpus iterator
    mm = gensim.corpora.MmCorpus(corpus_mm)

    with io.open("%s_%s.csv" % (relevant_articles_file, num_topic), 'w', encoding='utf8') as rel_art_file:
        # iterate over docs in corpus
        for index in range(mm.num_docs):
            # get proportions of doc from lda_model
            # probability that document consists of a topic must be greater than 1e-8
            doc_topics = my_lda_model.get_document_topics(mm[index],
                                                          minimum_probability=None,
                                                          minimum_phi_value=None,
                                                          per_word_topics=False)

            # calculate cumulative probability for article
            topic_proportion_dict = dict(doc_topics)
            cumulative_probability = 0
            for t in relevant_topics:
                if t in topic_proportion_dict:
                    cumulative_probability += topic_proportion_dict[t]

			# output document and the calculated relevance probability
			line = u"%(index)d;%(filename)s;%(probability)f\n" % {
				'index': index,
				'filename': filename_index[index],
				'probability': cumulative_probability
			}
			rel_art_file.write(line)
			rel_art_file.flush()


def get_file_names(processed_files):
    """
    reads the file names from a text file (one file name per line)
    returns a dict with the index and the fileName (order in which they appear in file)
    :param processed_files:
    :return: dictionary(id=>filenames)
    """

    f = open(processed_files, "r")
    file_dict = {}
    index = 0
    lines = f.readlines()
    for line in lines:
        if ".txt" in line:
            file_dict[index] = line.strip()
            index += 1
    f.close()
    return file_dict


if __name__ == "__main__":
    for num_topic in config.num_topics:
        infer_topics(lda_model=config.paths.lda_model,
                     relevant_topics=config.relevant_topics[num_topic],
                     processed_files=config.paths.files_processed,
                     corpus_mm=config.paths.corpus_mm,
                     relevant_articles_file=config.paths.relevant_articles)
