#!/usr/bin/env python
# -*- coding: utf-8 -*-

import unicodedata
import regex
from six import u
from pattern.vector import stopwords
import os
from pattern.de import find_lemmata as find_lemmata_de
from pattern.en import find_lemmata as find_lemmata_en
from zemberek import ZemberekGateway
import logging

REPLACE_DASH = regex.compile(ur'[\p{Pd}\/\\]', regex.UNICODE)  # replace with \s
TOKENIZE = regex.compile(ur'((\p{P}*+(?:\p{L}|\p{M}|\d)+\p{P}*+)+)', regex.UNICODE)  # tokenizer
STRIP_QUOTES = regex.compile(ur'[\p{Ps}\p{Pe}\p{Pi}\p{Pf}\p{Pc}]', regex.UNICODE)  # remove before lemmatization
STRIP_PUNCTUATION = regex.compile(ur'\p{P}', regex.UNICODE)  # remove after lemmatization


""" Read turkish stop words """
with open(os.path.join(os.path.dirname(__file__), 'stopwords-tr.txt')) as sf:
    stopwords['tr'] = []
    for line in sf.readlines():
        line = line.strip().lower().decode('utf-8')
        if len(line) > 0 and not line.startswith('#'):
            stopwords['tr'].append(line)


class NormalizedLine(object):
    def __init__(self, line, language):
        """
        normalizes a line from the keyword file
        :param line: original line from keyword file
        """
        if not isinstance(line, unicode):
            line = u(line)

        # store original line
        self.orig = line

        # strip control characters and lowercase the string
        self.normalized = line.strip().lower()

        if len(self.normalized) == 0:
            self.normalized = ""
            self.token = []
        else:
            # replace -
            self.normalized = REPLACE_DASH.sub(' ', self.normalized)

            # strip quotes
            self.normalized = STRIP_QUOTES.sub('', self.normalized)

            # strip other punctuation
            self.normalized = STRIP_PUNCTUATION.sub('', self.normalized)

            # normalize unicodes, tokenize (normalizes spaces)
            self.token = [unicodedata.normalize('NFKC', match.group())
                               for match in TOKENIZE.finditer(self.normalized)]

            self.token = [token for token in self.token if token not in stopwords[language]]

            self.normalized = u(' ').join(self.token)

    def get(self):
        """
        retrieves the object as tuple
        :return: (original, normalized, token)-tuple
        """
        return self.orig, self.normalized, self.token

    def __eq__(self, other):
        """
        compares two NormalizedLine objects. They are considered equal, if the normalized
        component is equal, equality is not computed on the original component
        :param other: the second NormalizedLine object
        :return: boolean equality
        """
        return self.normalized == other.normalized

    def __hash__(self):
        """
        hash function for NormalizedLine objects
        the hash is computed only on the normalized component, the original component is discarded
        :return: hash
        """
        return self.normalized.__hash__()


def pre_process_keyword(lines, language):
    """
    :param lines: list of lines from keyword file
    :param language: language for preprocessing / lemmatization
    :return: generator to iterate over the preprocessed tokens
    """

    """
    remove empty lines, normalize all lines
    """

    lines_normalized = [NormalizedLine(line, language) for line in lines if len(line.strip()) > 0]

    def get(elem_list):
        """
        wrapper generator, retrieve element as tuple (see get in class NormalizedLine)
        :param elem_list: the list of NormalizedLine objects
        :return: generator that returns the NormalizedLine objects as tuples
        """
        for elem in elem_list:
            yield elem.get()

    logging.info("%d of %d keywords left after normaliztation and deduplication." % (len(lines_normalized), len(lines)))

    # lemmatize
    for line_orig, line_normalized, line_token in get(lines_normalized):
        # lemmatize
        tokens = []
        for token in line_token:
            if language == 'de':
                # lemmatize all possible pos tags
                possible_keywords = [[token, tag] for tag in ['NNS', 'JJ', 'VB']]
                possible_keywords = find_lemmata_de(possible_keywords)
                # strip duplicates
                tokens.append(get_unique([token] + [lemma[2].lower() for lemma in possible_keywords]))
            elif language == 'tr':
                possible_keywords = ZemberekGateway.find_lemmata(token)
                tokens.append(get_unique([token] + [lemma.rsplit("/", 1)[0] for lemma in possible_keywords]))
            else:
                # lemmatize all possible pos tags
                possible_keywords = [[token, tag] for tag in ['NNS', 'JJ', 'VB']]
                possible_keywords = find_lemmata_en(possible_keywords)

                # strip duplicates
                tokens.append(get_unique([token] + [lemma[2].lower() for lemma in possible_keywords]))
        yield line_orig, line_normalized, tokens


def get_unique(seq):
    seen = set()
    seen_add = seen.add
    return [x for x in seq if not (x in seen or seen_add(x))]


def remove_pos(token):
    """
    :param token: token with pos tag
    :return: token without pos tag
    """
    try:
        return token.rsplit("/", 1)[0]
    except IndexError:
        return token