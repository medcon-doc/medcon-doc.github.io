Topic Modeling Pipeline for 'Expert-Informed Topic Models for Document Set Discovery'
Authors: blinded
#############

This is the topic modeling pipeline as described in the paper 'Expert-Informed Topic Models for Document Set Discovery'.

Configuration for the topic modeling is supplied via the command line parameter --config / -c and a path to a config.json. An example is provided in example.config.json.

Text pre-processing for English and German is built in via the Python pattern package. For Turkish pre-processing, the P4J package is needed and the Zemberek-based Java server needs to be running (see Appendix - Turkish Lemmatizer).

An example run could look like this:
# python -u script01_createMedConCorpus_v2.py -c example.config.json
# python -u script02_runLDA_v2.py -c example.config.json
# python -u script03_findRelevantTopics_v2.py -c example.config.json
# python -u script04_selectRelevantArticles_v2.py -c example.config.json

Requirements:
- pattern
- gensim
- P4J