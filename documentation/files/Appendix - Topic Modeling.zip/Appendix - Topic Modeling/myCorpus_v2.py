#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (C) 2010 Radim Rehurek <radimrehurek@seznam.cz>
# Copyright (C) 2012 Lars Buitinck <larsmans@gmail.com>
# Licensed under the GNU LGPL v2.1 - http://www.gnu.org/licenses/lgpl.html


"""
Construct a corpus from a Wikipedia (or other MediaWiki-based) database dump.

If you have the `pattern` package installed, this module will use a fancy
lemmatization to get a lemma of each token (instead of plain alphabetic
tokenizer). The package is available at https://github.com/clips/pattern .

See scripts/process_wiki.py for a canned (example) script based on this
module.
"""

import codecs
import logging
import multiprocessing
import os
import unicodedata
import regex
from gensim import utils
from gensim.corpora.dictionary import Dictionary
from gensim.corpora.textcorpus import TextCorpus
from pattern.de import parse as parse_de
from pattern.en import parse as parse_en
from py4j.protocol import Py4JJavaError

from zemberek import ZemberekGateway
from six import u

logger = logging.getLogger('gensim.corpora.mycorpus')

# ignore articles shorter than ARTICLE_MIN_WORDS characters (after full preprocessing)
ARTICLE_MIN_WORDS = 50

STRIP_NUMERIC = regex.compile(ur'(((?![\d])\p{P}*+\p{L}\p{M}*+\p{P}*+)+)', regex.UNICODE)
STRIP_ALL = regex.compile(ur'(((?![\d])\p{L}\p{M}*+)+)', regex.UNICODE)


REPLACE_DASH = regex.compile(ur'[\p{Pd}\/\\]', regex.UNICODE)  # replace with \s
TOKENIZE = regex.compile(ur'((\p{P}*+(?:\p{L}|\p{M}|\d)+\p{P}*+)+)', regex.UNICODE)  # tokenizer
STRIP_QUOTES = regex.compile(ur'[\p{Ps}\p{Pe}\p{Pi}\p{Pf}\p{Pc}]', regex.UNICODE)  # remove before lemmatization
STRIP_PUNCTUATION = regex.compile(ur'\p{P}', regex.UNICODE)  # remove after lemmatization
ALLOWED_TAGS = regex.compile('(NN|VB|RB|JJ)')


def lemmatize(
        content, language, pageid,
        stopwords=frozenset(), min_length=2, max_length=15):
    """
    This function is only available when the optional 'pattern' package is installed.

    Use the English lemmatizer from `pattern` to extract UTF8-encoded tokens in
    their base form=lemma, e.g. "are, is, being" -> "be" etc.
    This is a smarter version of stemming, taking word context into account.

    Only considers nouns, verbs, adjectives and adverbs by default (=all other lemmas are discarded).

    >>> lemmatize('Hello World! How is it going?! Nonexistentword, 21')
    ['world/NN', 'be/VB', 'go/VB', 'nonexistentword/NN']

    >>> lemmatize('The study ranks high.')
    ['study/NN', 'rank/VB', 'high/JJ']

    >>> lemmatize('The ranks study hard.')
    ['rank/NN', 'study/VB', 'hard/RB']

    """
    if language in ['de', 'tr', 'en']:
        # normalize
        # replace '-'
        # tokenize
        content = REPLACE_DASH.sub(' ', content)

        content = u(' ').join([unicodedata.normalize('NFKC', match.group())
                               for match in TOKENIZE.finditer(content)])

        # strip quotes
        content = STRIP_QUOTES.sub('', content)

        # lemmatize
        if language == 'de':
            # de
            parsed = parse_de(content, lemmata=True, collapse=False)
        elif language == 'tr':
            # tr
            try:
                parsed = ZemberekGateway.parse(content)
            except Py4JJavaError as e:
                logging.info("Uncaught Java Exception at %s" % pageid)
                logging.info(unicode(e))
                parsed = []
        else:
            # en
            parsed = parse_en(content, lemmata=True, collapse=False)

        result = []
        if language == 'tr':
            for dirty_lemma in parsed:
                dirty_lemma, tag = dirty_lemma.rsplit("/", 1)
                lemma = STRIP_PUNCTUATION.sub('', dirty_lemma)
                if min_length <= len(lemma) <= max_length and not lemma.startswith('_') and lemma not in stopwords:
                    lemma = lemma.lower()
                    lemma += "/" + tag
                    result.append(lemma.encode('utf8'))
        else:
            for sentence in parsed:
                for token, tag, _, _, dirty_lemma in sentence:
                    # strip 'all other punctuation'
                    lemma = STRIP_PUNCTUATION.sub('', dirty_lemma)
                    if min_length <= len(lemma) <= max_length and not lemma.startswith('_') and lemma not in stopwords:
                        # filter tags
                        if ALLOWED_TAGS.match(tag):
                            lemma = lemma.lower()
                            lemma += "/" + tag[:2]
                            result.append(lemma.encode('utf8'))
        return result
    else:
        raise BaseException("Language '%s' not available" % language)


def tokenize(content):
    """
    Tokenize a piece of text from wikipedia. The input string `content` is assumed
    to be mark-up free (see `filter_wiki()`).

    Return list of tokens as utf8 bytestrings. Ignore words shorted than 2 or longer
    that 15 characters (not bytes!).
    """
    # TODO maybe ignore tokens with non-latin characters? (no chinese, arabic, russian etc.)
    return [token.encode('utf8') for token in utils.tokenize(content, lower=True, errors='ignore')
            if 2 <= len(token) <= 15 and not token.startswith('_')]


def extract_pages(rootDir):
    """
   read articles from files.

   title = article url
   text = content
   pageid = path to file

    Return an iterable over (str, str, str) which generates (title, content, pageid) triplets.


    """

    for dirName, subdirList, fileList in list(os.walk(rootDir)):
        # this is the YIELD loop!
        for fname in fileList:
            f = open(dirName + "/" + fname, 'r')

            text = f.read().decode('utf-8').strip()

            if len(text) == 0:
                title = ""
            else:
                try:
                    title = text.split("\n", 2)[0]
                except IndexError:
                    title = ""

            pageid = dirName + "/" + fname

            yield title, text, pageid  # empty page will yield None

            f.close()


def process_article(args):
    """
    Parse a wikipedia article, returning its content as a list of tokens
    (utf8-encoded strings).
    """
    text, title, pageid, language = args

    # if lemmatize:
    #     result = utils.lemmatize(text)
    # else:
    #     result = tokenize(text)
    result = lemmatize(text, language, pageid)
    return result, title, pageid


class MyCorpus(TextCorpus):
    """
    Treat a wikipedia articles dump (\*articles.xml.bz2) as a (read-only) corpus.

    The documents are extracted on-the-fly, so that the whole (massive) dump
    can stay compressed on disk.

    >>> wiki = WikiCorpus('enwiki-20100622-pages-articles.xml.bz2') # create word->word_id mapping, takes almost 8h
    >>> MmCorpus.serialize('wiki_en_vocab200k.mm', wiki) # another 8h, creates a file in MatrixMarket format plus file with id->word

    """
    def __init__(self, config, processes=None, dictionary=None, filter_namespaces=('0',)):
        """
        Initialize the corpus. Unless a dictionary is provided, this scans the
        corpus once, to determine its vocabulary.

        If `pattern` package is installed, use fancier shallow parsing to get
        token lemmas. Otherwise, use simple regexp tokenization. You can override
        this automatic logic by forcing the `lemmatize` parameter explicitly.

        """

        self.config = config

        # file to save order of processed files
        self.metadata = False
        if processes is None:
            processes = max(1, multiprocessing.cpu_count() - 1)
        self.processes = processes

        if dictionary is None:
            self.dictionary = Dictionary(self.get_texts())
        else:
            self.dictionary = dictionary

    def get_texts(self):
        """
        Iterate over the dump, returning text version of each article as a list
        of tokens.

        Only articles of sufficient length are returned (short articles & redirects
        etc are ignored).

        Note that this iterates over the **texts**; if you want vectors, just use
        the standard corpus interface instead of this function::

        >>> for vec in wiki_corpus:
        >>>     print(vec)
        """
        articles, articles_all = 0, 0
        positions, positions_all = 0, 0

        logger.info("corpus: %s" % self.config.paths.corpus)
        logger.info("language: %s" % self.config.language)

        texts = ((text, title, pageid, self.config.language) for title, text, pageid in
                 extract_pages(self.config.paths.corpus))
        pool = multiprocessing.Pool(self.processes)

        files_processed = codecs.open(self.config.paths.files_processed, encoding='utf-8', mode='w+')
        files_filtered = codecs.open(self.config.paths.files_filtered, encoding='utf-8', mode='w+')

        # process the corpus in smaller chunks of docs, because multiprocessing.Pool
        # is dumb and would load the entire input into RAM at once...
        for group in utils.chunkize(texts, chunksize=10 * self.processes, maxsize=1):
            for tokens, title, pageid in pool.imap(process_article, group):  # chunksize=10):
                articles_all += 1
                positions_all += len(tokens)
                # article redirects and short stubs are pruned here
                if len(tokens) < ARTICLE_MIN_WORDS:
                    files_filtered.write(pageid + "\n")
                    files_filtered.flush()
                    continue
                files_processed.write(pageid + "\n")
                files_processed.flush()
                articles += 1
                positions += len(tokens)
                if self.metadata:
                    yield (tokens, (pageid, title))
                else:
                    yield tokens
        pool.terminate()

        # close fileWriter
        files_processed.close()
        files_filtered.close()

        logger.info(
            "finished iterating over corpus of %i documents with %i positions"
            " (total %i articles, %i positions before pruning articles shorter than %i words)",
            articles, positions, articles_all, positions_all, ARTICLE_MIN_WORDS)
        self.length = articles  # cache corpus length

# endclass WikiCorpus



