# -*- coding: 'utf-8' -*-

"""
Train LDA topic models on the corpus files.

This creates LDA topic models for each of the specified topic model sizes:
* `NAME_ldamodel_NUMTOPICS`: The LDA model for a given number of topics

NAME and NUMTOPICS can be set in config.json

Example: python -u script02_runLDA_v2.py -c example.config.json
"""

import bz2
import gensim
import logging
from config import config


def run_lda(num_topics):
	# log the paths to the input files used
    logging.info("dictionary: %s" % config.paths.dictionary)
    logging.info("corpus: %s" % config.paths.corpus_mm)
    logging.info("lda_model: %s_%s" % (config.paths.lda_model, num_topics))

	# load the word dictionary
    id2word = gensim.corpora.Dictionary.load_from_text(bz2.BZ2File(config.paths.dictionary))
    print(id2word)
	
    # load corpus iterator
    mm = gensim.corpora.MmCorpus(config.paths.corpus_mm)
    
	# output corpus information
	print(mm)
	
    # RUN LDA
    # extract LDA topics, using 1 pass and updating once every 1 chunk (10,000 documents)
    lda = gensim.models.ldamodel.LdaModel(corpus=mm, id2word=id2word, num_topics=num_topics, update_every=1,
                                           chunksize=10000, passes=3)  # change lda parameters here
										   
	# save the LDA model for the next step
    lda.save("%s_%s" % (config.paths.lda_model, num_topics))
    return True


if __name__ == "__main__":
	# initialize logging
    logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)
    
	# specify path to input data, model sizes and result path in config.json
	
	# generate LDA models for each of the specified sizes
    for num_topic in config.num_topics:
        logging.info("Staring LDA with %d topics" % num_topic)
        run_lda(num_topic)
	
	# log that we are done
    logging.info("Done")
