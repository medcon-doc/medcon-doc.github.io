# -*- coding: 'utf-8' -*-

"""

File providing the configuration for the topic modeling scripts.
A configuration can be provided to each script via the command line parameter --config / -c
An example config is provided in example.config.json

"""

import argparse
import json
import os.path
from collections import namedtuple


Paths = namedtuple('Paths', [
    # Main
    'corpus', 'keyword_file', 'keywords_hierarchy', 'results',

    # Script 01
    'files_processed', 'files_filtered', 'corpus_mm', 'tfidf_model', 'tfidf_mm', 'dictionary',
    # Script 02
    'lda_model',
    # Script 02a
    'topic_model_dump_file',
    # Script 03
    'document_frequency_cache', 'keywords_found_sorted', 'relevant_topics_sorted',
    # Script 04
    'relevant_articles',
])


class PathsMaker(Paths):
    @staticmethod
    def make(cfg):
        return Paths(
            # Main
            corpus=cfg['corpus_path'],
            keyword_file=cfg['keyword_file_path'],
            keywords_hierarchy=cfg['keywords_hierarchy_path'],
            results=cfg['results_path'],

            # Script 01
            files_processed=os.path.join(cfg['results_path'], '%s_filesProcessed.txt' % cfg['name']),
            files_filtered=os.path.join(cfg['results_path'], '%s_filesFiltered.txt' % cfg['name']),
            corpus_mm=os.path.join(cfg['results_path'], '%s_bow.mm' % cfg['name']),
            tfidf_model=os.path.join(cfg['results_path'], '%s.tfidf_model' % cfg['name']),
            tfidf_mm=os.path.join(cfg['results_path'], '%s_tfidf.mm' % cfg['name']),
            dictionary=os.path.join(cfg['results_path'], '%s_wordids.txt.bz2' % cfg['name']),

            # Script 02
            lda_model=os.path.join(cfg['results_path'], '%s_ldamodel' % cfg['name']),

            # Script 02a
            topic_model_dump_file=os.path.join(cfg['results_path'], '%s_viewTopicModel_top.csv' % cfg['name']),

            # Script 03
            document_frequency_cache=os.path.join(cfg['results_path'], '%s_documentFrequencyCache' % cfg['name']),
            keywords_found_sorted=os.path.join(cfg['results_path'], '%s_keywordsFoundSorted' % cfg['name']),
            relevant_topics_sorted=os.path.join(cfg['results_path'], '%s_relevantTopicsSorted' % cfg['name']),

            # Script 04
            relevant_articles=os.path.join(cfg['results_path'], '%s_relevantArticles' % cfg['name']),
        )


Config = namedtuple('Config', [
            'name', 'num_topics', 'language', 'relevant_topics', 'paths'
])


class ConfigReader(Config):
    @staticmethod
    def read():
        parser = argparse.ArgumentParser()
        parser.add_argument("--config", "-c", help="path to config file")
        args = parser.parse_args()

        with open(args.config) as cf:
            json_config = json.load(cf)
            return Config(
                name=json_config['name'],
                num_topics=[int(num) for num in json_config['num_topics']],
                language=json_config['language'],
                relevant_topics=ConfigReader.rel_topics(json_config),
                paths=PathsMaker.make(json_config)
            )

    @staticmethod
    def rel_topics(json_config):
        rel_topics = dict()
        for num_topic in json_config['num_topics']:
            num_topic = int(num_topic)
            rel_topics[num_topic] = []
            if str(num_topic) in json_config['relevant_topics']:
                for rel_topic in json_config['relevant_topics'][str(num_topic)]:
                    rel_topics[num_topic].append(int(rel_topic))
        return rel_topics
config = ConfigReader.read()
