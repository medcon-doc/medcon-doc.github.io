# -*- coding: 'utf-8' -*-

"""

File providing the interfaces with the Zemberek server for the Turkish NLP (Lemmatization)

"""

from py4j.java_gateway import JavaGateway


class ZemberekGateway:
    def __init__(self):
        self.gateway = JavaGateway()
        self.app = self.gateway.entry_point

    def lemmatize(self, document):
        return self.app.lemmatize(document.encode('utf-8'))

    def analyze_word(self, word):
        return self.app.analyze_word(word.encode('utf-8'))

    @staticmethod
    def parse(document):
        zgw = ZemberekGateway()
        return zgw.lemmatize(document)

    @staticmethod
    def find_lemmata(word):
        zgw = ZemberekGateway()
        return zgw.analyze_word(word)
