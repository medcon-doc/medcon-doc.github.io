# -*- coding: 'utf-8' -*-

"""
Identify the relevant topics in the generated topics.

This creates LDA topic models for each of the specified topic model sizes:
* `NAME_documentFrequencyCache`: cache of the document frequencies in each topic
* `NAME_keywordsFoundSorted`: a csv file with match statistics of each of the provided keywords
* `NAME_relevantTopicsSorted`: a csv file with list of topics sorted by cumulative match probability

NAME be set in config.json

Example: python -u script03_findRelevantTopics_v2.py -c example.config.json
"""

from __future__ import print_function
from __future__ import division
from collections import Counter

from gensim.models.ldamodel import *
from gensim.corpora import MmCorpus
import io
from config import config
import six

from preprocessing import pre_process_keyword, remove_pos
import json
import gzip
from collections import namedtuple


HighestMatch = namedtuple('HighestMatch', ['topic', 'probability', 'word'])
FirstMatch = namedtuple('FirstMatch', ['term', 'probability'])


def import_keywords(keyword_file):
    """ opens the given file and reads the keywords from it
    :returns a list of keywords
    """
    logging.info("Reading keyword list...")
    with io.open(keyword_file, 'r', encoding='utf8') as f:
        # read file, replace bom
        content = f.read().replace(u'\ufeff', '')

    keyword_list = content.split("\n")
    logging.info("Done. (" + str(len(keyword_list)) + " keywords found.)")
    return keyword_list


def find_relevant_topics(keyword_file, language, corpus_mm, lda_model, document_frequency_cache_file,
                         keywords_found_path, relevant_topics_path):
    """

    calculates the relevance of topics given a list of keywords

    collect the most probable topics given the keyword terms
    (built-in function that returns "most probable" topics)
    choose topics that were returned most often


    :return:
    index of relevant topics
    """

    # read keyword list
    keyword_list = import_keywords(keyword_file)

    # load lda model
    my_lda_model = LdaModel.load(lda_model)

    # get vocabulary (termToId)
    vocab_id2word = my_lda_model.id2word
    # reverse dictionary and split off pos tags
    vocab_word2id = dict((v, k) for k, v in six.iteritems(vocab_id2word))

    df = DocumentFrequencies(corpus_mm, my_lda_model, document_frequency_cache_file)
    topic_document_freq, num_docs = df.get()

    ''' generate topics with keyword hits and keywords with topic hits '''
    # build lookup dictionary word => ids (without pos tags, there might be several hits)
    vocab_word2ids = dict()
    for k, v in six.iteritems(vocab_id2word):
        v = remove_pos(v)

        if v not in vocab_word2ids:
            vocab_word2ids[v] = []

        vocab_word2ids[v].append(k)

    # init counters (hit counters, total, single, multi)
    relevant_topic_freq = Counter()
    relevant_topic_freq_single = Counter()
    relevant_topic_freq_multi = Counter()

    topic_term_counter = Counter()

    # init list to store keywords and their topics they matched in
    keyword_topics = []

    # store first matches for each topic
    def_val = FirstMatch(term="", probability=0)
    topics_first_matches = dict((k, def_val) for k in range(0, my_lda_model.num_topics))
    topics_cumulative_match_probability = dict((k, set()) for k in range(0, my_lda_model.num_topics))

    # iterate over keywords
    for line_orig, line_processed, tokens in pre_process_keyword(keyword_list, language):
        # store count of tokens in each topic
        topic_term_counter_line = Counter()
        topics = set()

        # get highest matching topics for each token
        hm = HighestMatch(probability=0, topic=-1, word="")

        for word in tokens:
            # get index for term
            for possible_token in word:
                if possible_token in vocab_word2ids:
                    for term_index in vocab_word2ids[possible_token]:
                        # get most probable topics for term
                        # CHANGE THIS PARAMETER IF YOU GET TOO MANY OR TOO FEW TOPICS BACK!!!!
                        # set to 1e-8 (mininum for gensim) and filter later in excel
                        top_topics_for_term = my_lda_model.get_term_topics(term_index, minimum_probability=1e-8)

                        for topic_id, topic_probability in top_topics_for_term:
                            topics.add(topic_id)

                            # store first match in each topic
                            if topic_probability > topics_first_matches[topic_id].probability:
                                topics_first_matches[topic_id] = FirstMatch(term=possible_token,
                                                                            probability=topic_probability)

                            # store highest match for each keyword
                            if topic_probability > hm.probability:
                                hm = HighestMatch(topic=topic_id,
                                                  probability=topic_probability,
                                                  word=possible_token)

                            # add matched term to cumulative topic probability
                            topics_cumulative_match_probability[topic_id].add((possible_token, topic_probability))

                            # remember which topics have been hit by that line, only allow one hit per line
                            topic_term_counter_line['%d\t%d' % (topic_id, term_index)] = 1

        # merge line counter with global hit counter
        topic_term_counter += topic_term_counter_line

        # get topic Ids and collect them in
        for topic in topics:
            relevant_topic_freq[topic] += 1
            if len(tokens) > 1:
                relevant_topic_freq_multi[topic] += 1
            else:
                relevant_topic_freq_single[topic] += 1

        # store all relevant topics for a keyword
        keyword_topics.append((line_orig, line_processed, list(topics), hm))

    # iterate over keywords and print out topics found descending by number of topics found for a given keyword
    print_string = u''
    for keyword, processed, topics, hm in sorted(keyword_topics, key=lambda x: len(x[2]), reverse=True):
        print_string += u'%(keyword)s;%(processed)s;%(hm_word)s;%(hm_topic)d;' \
                        u'%(hm_probability)0.4f;%(hits)d;%(topics)s\n' % {
                            'keyword': keyword,
                            'processed': processed,
                            'hm_word': hm.word,
                            'hm_topic': hm.topic,
                            'hm_probability': hm.probability,
                            'hits': len(topics),
                            'topics': six.u(',').join([str(topic) for topic in topics])
                        }

    with io.open(keywords_found_path, 'w', encoding='utf8') as keywords_found_file:
        keywords_found_file.write(print_string)

    logging.info("Keyword statistics written to: " + keywords_found_path)

    # iterate over relevant topics descending by frequency
    print_string = u''
    for top, frequency in relevant_topic_freq.most_common():
        logging.info("Relevant Topic #%s: %s times" % (top, frequency))

        # get top 100 terms of topic
        terms = LdaModel.show_topic(my_lda_model, top, 100)

        # zip list with hit frequency
        def get_frequency(tpc, trm):
            return topic_term_counter['%d\t%d' % (tpc, vocab_word2id[trm])]

        terms = [(term[0], term[1], get_frequency(top, term[0])) for term in terms]

        cm_probability = sum(map(lambda x: x[1], topics_cumulative_match_probability[top]))

        print_string += u"%(topic)d;%(total)d;%(single)d;%(multi)d;%(documents)s;%(corpus_ratio)0.2f;" \
                        u"%(cm_probability)0.4f;%(matched_terms)d;%(fm_term)s;%(fm_probability)0.4f;%(terms)s\n" % {
                            'topic': top,
                            'total': frequency,
                            'single': relevant_topic_freq_single[top],
                            'multi': relevant_topic_freq_multi[top],
                            'documents': topic_document_freq[top],
                            'corpus_ratio': (topic_document_freq[top] / float(num_docs))*100,
                            'cm_probability': cm_probability,
                            'matched_terms': len(topics_cumulative_match_probability[top]),
                            'fm_term': topics_first_matches[top].term,
                            'fm_probability': topics_first_matches[top].probability,
                            'terms': ";".join(map(lambda term: '%s/%0.4f/%d' % (term[0], term[1], term[2]), terms)),
                        }

    with io.open(relevant_topics_path, 'w', encoding='utf8') as relevant_topics_file:
        relevant_topics_file.write(print_string)

    logging.info("Topics sorted by relevance written to: " + relevant_topics_path)

    return relevant_topic_freq.keys()


class DocumentFrequencies(object):
    def __init__(self, corpus_mm, my_lda_model, cache_file):
        self.corpus_mm = corpus_mm
        self.my_lda_model = my_lda_model
        self.cache_file = cache_file

    def get(self):
        mm = MmCorpus(self.corpus_mm)
        num_docs = mm.num_docs

        if self.cache_exists():
            with gzip.open(self.cache_file, 'rb') as f:
                return Counter(dict([(int(k), int(v)) for k, v in six.iteritems(json.load(f))])), num_docs
        else:
            freq = self.generate()
            with gzip.open(self.cache_file, 'wb') as f:
                json.dump(dict(freq), f)
            return freq, num_docs

    def cache_exists(self):
        if os.path.isfile(self.cache_file):
            return True
        return False

    def generate(self):
        """ generate distribution of documents for each topic (amount of documents in each topic) """
        logging.info("Start bulding document distribution for each topic")
        # init counter topic=>documents
        topic_document_freq = Counter()
        # load corpus iterator
        mm = MmCorpus(self.corpus_mm)
        logging.info(mm)
        # iterate over docs in corpus
        for index in range(mm.num_docs):
            if index % 10000 == 0:
                logging.info("Processing document #%d of %d documents" % (index, mm.num_docs))

            # get proportions of doc from lda_model
            # probability that document consists of a topic must be greater than 1e-8
            for topic, _ in self.my_lda_model.get_document_topics(mm[index]):
                topic_document_freq[topic] += 1
        logging.info("Done bulding document distribution for each topic")
        return topic_document_freq


if __name__ == "__main__":
    logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)
    for num_topic in config.num_topics:
        logging.info("Generating statistics for %d topics" % num_topic)
        find_relevant_topics(keyword_file=config.paths.keyword_file,
                             language=config.language,
                             lda_model="%s_%s" % (config.paths.lda_model, num_topic),
                             corpus_mm=config.paths.corpus_mm,
                             document_frequency_cache_file="%s_%s" % (config.paths.document_frequency_cache, num_topic),
                             keywords_found_path="%s_%s.csv" % (config.paths.keywords_found_sorted, num_topic),
                             relevant_topics_path="%s_%s.csv" % (config.paths.relevant_topics_sorted, num_topic))
